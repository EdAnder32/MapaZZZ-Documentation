# FAQ

### A API é gratuita?

Sim, o uso básico da API é gratuito.

### Preciso de autenticação?

Para a maioria dos dados públicos, não. Apenas dados sensíveis exigem token.
