# POST /reportes

Permite enviar um novo reporte de zona de risco.

### Corpo esperado

```json
{
  "regiao": "Huíla",
  "latitude": -15.123,
  "longitude": 13.456,
  "descricao": "Muitos casos próximos"
}
```