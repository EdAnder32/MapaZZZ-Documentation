# GET /estatisticas

Retorna estatísticas agregadas sobre reportes de malária por região.

```json
{
  "total_zonas": 120,
  "regioes_criticas": ["Luanda", "Huambo"],
  "ultima_atualizacao": "2025-07-01T12:00:00Z"
}
```