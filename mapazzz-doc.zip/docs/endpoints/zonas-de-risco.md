# GET /zonas-de-risco

Retorna as zonas de risco ativas no momento.

### Resposta de exemplo

```json
[
  {
    "id": "123",
    "regiao": "Luanda",
    "nivel_risco": "alto",
    "latitude": -8.838,
    "longitude": 13.234,
    "verificado": true
  }
]
```