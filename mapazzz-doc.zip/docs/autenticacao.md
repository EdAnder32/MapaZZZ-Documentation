# Autenticação

Alguns endpoints requerem autenticação via JWT (JSON Web Token).

## Obter token

Faça login:

```
POST /auth/login
```

Envie no header:

```
Authorization: Bearer SEU_TOKEN
```
