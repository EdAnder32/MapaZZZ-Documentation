# MapaZZZ API

Bem-vindo à API pública do **MapaZZZ**, um sistema que mapeia zonas de risco de malária em tempo real, com base em dados de usuários e instituições de saúde.

---

## 🔎 Visão geral

- 📍 Reportes de zonas com risco de malária
- 🤖 Processamento com inteligência artificial
- 🏥 Validação feita por instituições confiáveis
- 📊 Acesso a dados abertos via API REST

---

## 🚀 O que você pode fazer com a API?

- Obter zonas de risco atualizadas
- Consultar estatísticas por região
- Verificar reportes validados
- Acompanhar o histórico de alertas

---

## 📡 Base URL

```
https://api.mapazzz.org/v1
```

---

## 🔐 Autenticação

A maioria dos endpoints públicos **não requer autenticação**, mas alguns dados sensíveis ou estatísticas avançadas requerem um **token JWT**.
